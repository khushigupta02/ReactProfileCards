import React, { Component } from 'react';
import './App.css';
import First from './pages/first';
import '../src/css/style.css';
function App() {
  return (
    <div className="App">
      <First />
    </div>
  );
}

export default App;
